# Cycles Detection with Depht-First Search (DFS) Script

This Python script, `cycles.py`, implements the Depth-First Search (DFS) algorithm to detect cycles in a directed graph. This corresponds to point 2 of the homework. It reads the graph structure from an input file and writes the detected cycles (if any) to an output file.

## Team Members

- **David Alejandro Fuquen Florez**
- **Isabella Martinez Martinez**
- **Gustavo Andrés Mendez Hernández**

## Input File Format

The input file (e.g., `graph_cycles.in`) should contain one edge per line in the format:
```
<node1> <node2> <weight>
```
For example:
```
A B 4
A D 1
A E 5
B G 1
D B 2
D E 3
D F 8
E F 4
G F 2
```

## Output File Format

The output file (e.g., `cycles.out`) contains the detected cycles, one cycle per line in the format:
```
<node1> -> <node2> -> ... -> <nodek>
```
If no cycles are detected, the output file will contain the following message:
```
No self-loans were detected
```

For example, if the graph has cycles:
```
A -> B -> D
C -> E
```

Notice that we omit rewriting the cycle starting node.

## How to Run

1. Create an input file (e.g., `graph_cycles.in`) with the graph edges in the same directory as the script.
2. Open a terminal or command prompt and navigate to the script's directory.
3. Run the script using the following command:
   ```
   python cycles.py input_file.in output_file.out
   ```
   Replace `input_file.in` with the name of your input file and `output_file.out` with the desired output file name.

4. The script will write detected cycles to the specified output file.

## Example

### Input (`graph_cycles.in`):
```
A B 4
B D 5
D E 7
E A 1
A D 1
A E 5
B G 1
D B 2
D E 3
D F 8
E F 4
G F 2
A A 99
```

### Command:
```
python cycles.py graph.in cycles.out
```

### Output (`cycles.out`):
```
E -> A -> B -> D
B -> D
E -> A
A
```

## Requirements

- Python 3.6 or later

## Notes

- Ensure the input file follows the specified format.
- Negative edge weights are not allowed; the script will raise a `ValueError` if they are encountered.
- If the graph is acyclic, the output file will indicate that no cycles were detected.