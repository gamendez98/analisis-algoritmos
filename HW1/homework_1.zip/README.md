# Homework Documentation: Graph Algorithms

This repository contains implementations and related files for graph algorithms as part of the homework. The following points of the homework are covered:

## **Point 2: Cycle Detection**

The script `cycles.py` implements a cycle detection algorithm to identify cycles in a directed graph. It works alongside the following files:

- **`README_cycles.md`**: A detailed explanation of how to use `cycles.py`, input/output formats, and examples.
- **`graph_cycles.in`**: An example input file containing a directed graph's edges.
- **`cycles.out`**: An example output file containing detected cycles.

Refer to `README_cycles.md` for step-by-step instructions to use `cycles.py`.

### Quick Overview
- **Input File**: A `.in` file with graph edges in the format `<node1> <node2> <weight>`.
- **Output File**: A `.out` file containing detected cycles or a message if no cycles are found.

---

## **Point 5: Minimum Spanning Tree (MST)**

The script `kruskal.py` implements Kruskal's algorithm to find the Minimum Spanning Tree (MST) of an undirected graph. The following files are associated with this point:

- **`README_kruskal.md`**: A detailed guide on how to use `kruskal.py`, including input/output formats and examples.
- **`graph_kruskal.in`**: An example input file with an undirected graph's edges.
- **`mst.out`**: An example output file containing the MST's edges.

Refer to `README_kruskal.md` for detailed usage instructions.

### Quick Overview
- **Input File**: A `.in` file with graph edges in the format `<node1> <node2> <weight>`.
- **Output File**: A `.out` file containing edges of the MST.

---

## How to Navigate the Repository

Each point of the homework is self-contained within its own set of files:
- Point 2: `cycles.py`, `README_cycles.md`, `graph_cycles.in`, and `cycles.out`.
- Point 5: `kruskal.py`, `README_kruskal.md`, `graph_kruskal.in`, and `mst.out`.

To run the scripts:
1. Place the input files (`graph_cycles.in` or `graph_kruskal.in`) in the same directory as the respective scripts.
2. Follow the usage instructions in the associated README files.

---

## Requirements

- **Python Version**: 3.6 or later

---

## Notes

- Ensure the input files follow the specified formats strictly.
- The output files will overwrite any existing files with the same name in the directory.
- Error handling is included to validate input files and detect issues such as negative weights or invalid formats.

## Team Members

- **David Alejandro Fuquen Florez**
- **Isabella Martinez Martinez**
- **Gustavo Andrés Mendez Hernández**